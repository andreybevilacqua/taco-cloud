package com.abevilacqua.tacohystrixdashboard;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class TacoHystrixDashboardApplication {

	public static void main(String[] args) {
		SpringApplication.run(TacoHystrixDashboardApplication.class, args);
	}

}
